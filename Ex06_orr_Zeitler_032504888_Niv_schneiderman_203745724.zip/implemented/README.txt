Ex-6 implementation notes

we took the car model from homework 5 and added normals and matierial properteies to support lighting.
we then compared the colors against the given jar to find the correct settings.
we then added textur maping to the road and grass and the boxes, 
 
we did not implement the bounus

we add native folder with texturs all ready inside - just add the jogl dll